
public class InvalidNameException extends Exception {

}
