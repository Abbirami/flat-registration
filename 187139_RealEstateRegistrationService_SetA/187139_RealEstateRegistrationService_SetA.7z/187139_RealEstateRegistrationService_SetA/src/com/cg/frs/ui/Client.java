package com.cg.frs.ui;

import java.util.ArrayList;
import java.util.Scanner;

import javax.naming.InvalidNameException;

import com.cg.frs.dto.FlatOwner;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.service.FlatRegistrationServiceImpl;

public class Client {
	static FlatRegistrationServiceImpl fs = new FlatRegistrationServiceImpl();

	public static void main(String[] args) throws javax.naming.InvalidNameException {
		long registrationId = 0;
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("*******Real Estate Registration Service*******");
			System.out.println("1.Register Flat\n 2.Display Flat Registration Details\n 3.Exit");
			System.out.println("enter your choice");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("enter owner name:");
				String ownerName = sc.next();
				try {
					boolean isValid1 = fs.isvalidateName(ownerName);
				} catch (InvalidNameException ne) {
					System.out.println("Name should start with capital letter");
					break;
				}
				System.out.println("enter the owner id:");
				int ownerId = sc.nextInt();
				System.out.println("enter flat type:");
				String flatType = sc.next();
				System.out.println("enter flat area in sq.ft");
				int sqFt = sc.nextInt();
				System.out.println("enter desired rent amount:");
				int rentAmt = sc.nextInt();
				try {
					boolean isValid2 = fs.isvalidateRent(rentAmt);
				} catch (InvalidRentException re) {
					System.out.println("rent amount should be 3 digit");
					break;
				}
				System.out.println("enter desired deposit amount:");
				int depAmt = sc.nextInt();
				try {
					boolean isvalid3 = fs.isvalidateDeposit(depAmt);
				} catch (InvalidDepositException de) {
					System.out.println("deposit amount should be greater than 3 digit");
					break;
				}
				registrationId = (long) (Math.random() * 1000);
				System.out.println("Flat successfully registered.Registration id:" + registrationId);
				FlatRegistrationDTO flat = new FlatRegistrationDTO(ownerId, ownerName, flatType, sqFt, rentAmt, depAmt,
						registrationId);
				FlatRegistrationDTO ff = fs.registerFlat(flat);
				System.out.println("required details are:" + flat.getFlatType() + " " + flat.getOwnerName() + " "
						+ flat.getRegistrationId() + " " + flat.getSqFt() + " ");
				break;
			case 2:
				System.out.println("existing owner ids are:-[1,2,3]");
				System.out.println("please enter ur owner id:");
				ownerId = sc.nextInt();
				System.out.println("provide owner name");
				ownerName = sc.next();
				try {
					boolean isValid = fs.isvalidateName(ownerName);
				} catch (InvalidNameException ne) {
					System.out.println("Name should start with capital letter");
					break;
				}
				System.out.println("select flat type:");
				flatType = sc.next();
				System.out.println("enter the flat area:");
				sqFt = sc.nextInt();
				System.out.println("enter desired rent amount:");
				rentAmt = sc.nextInt();
				try {
					boolean isValid2 = fs.isvalidateRent(rentAmt);
				} catch (InvalidRentException re) {
					System.out.println("rent amount should be 3 digit");
					break;
				}
				System.out.println("enter desired deposit amount:");
				depAmt = sc.nextInt();
				try {
					boolean isvalid3 = fs.isvalidateDeposit(depAmt);
				} catch (InvalidDepositException de) {
					System.out.println("deposit amount should be greater than 3 digit");
					break;
				}

				System.out.println("enter mobile number");
				int mobile = sc.nextInt();
				System.out.println(ownerName + "" + mobile + "" + ownerId);
				FlatOwner fall = fs.getAllOwnerIds(ownerId);
				System.out.println(fall.getOwnerName());
				System.out.println(fall.getMobile());
				System.out.println(fall.getOwnerId());
				System.out.println("flat succesfully registered" + registrationId);
				break;
			case 3:
				System.out.println("quit from the application");
				System.exit(0);
				break;
			}
		}

	}

}
