package com.cg.frs.ui;

public class InvalidRentException extends Exception {

}
