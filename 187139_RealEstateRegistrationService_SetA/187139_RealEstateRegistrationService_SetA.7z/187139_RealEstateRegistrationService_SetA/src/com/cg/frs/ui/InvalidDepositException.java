package com.cg.frs.ui;

public class InvalidDepositException extends Exception {

}
