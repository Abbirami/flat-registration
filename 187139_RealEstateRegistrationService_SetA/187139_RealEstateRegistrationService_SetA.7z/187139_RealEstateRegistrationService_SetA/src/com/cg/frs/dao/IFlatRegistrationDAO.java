package com.cg.frs.dao;

import com.cg.frs.dto.FlatOwner;
import com.cg.frs.dto.FlatRegistrationDTO;

public interface IFlatRegistrationDAO {
	FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat);
	FlatOwner getAllOwnerIds(int ownerId);

	

}
