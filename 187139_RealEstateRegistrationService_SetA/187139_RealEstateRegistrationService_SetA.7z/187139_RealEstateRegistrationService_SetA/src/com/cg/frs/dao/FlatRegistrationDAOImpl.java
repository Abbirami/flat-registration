package com.cg.frs.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.frs.dto.FlatOwner;
import com.cg.frs.dto.FlatRegistrationDTO;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO{
	HashMap<Integer,FlatRegistrationDTO>hm =null;
	public FlatRegistrationDAOImpl() {
		// TODO Auto-generated constructor stub
		hm=new HashMap<Integer,FlatRegistrationDTO>();
	}
	HashMap<Integer,FlatOwner>owners=null;
	public  void FlatOwner() {
	owners.put(1,new FlatOwner(1,"vaishali",9023002));
	owners.put(2, new FlatOwner(2,"megha",9643224));
	owners.put(3, new FlatOwner(3,"manish",564756976));
	}

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		// TODO Auto-generated method stub
		hm.put((int) flat.getRegistrationId(),flat);
		return flat;
	}

	@Override
	public com.cg.frs.dto.FlatOwner getAllOwnerIds(int ownerId) {
		// TODO Auto-generated method stub
		FlatOwner fog=owners.get(ownerId);
		return fog;
	}

	
	

		
	
}
