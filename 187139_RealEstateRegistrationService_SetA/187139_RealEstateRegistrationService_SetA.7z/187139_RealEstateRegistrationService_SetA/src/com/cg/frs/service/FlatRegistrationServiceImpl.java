package com.cg.frs.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.naming.InvalidNameException;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dto.FlatOwner;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.ui.InvalidDepositException;
import com.cg.frs.ui.InvalidRentException;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {

	FlatRegistrationDAOImpl fd = new FlatRegistrationDAOImpl();

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		// TODO Auto-generated method stub
		FlatRegistrationDTO fb = fd.registerFlat(flat);
		return fb;
	}


	public boolean isvalidateName(String ownerName) throws InvalidNameException{
		// TODO Auto-generated method stub
		boolean res=Pattern.matches("[A-Z][a-zA-Z]*",ownerName);
		if(res==false)
			throw new InvalidNameException(ownerName);
		return res;
	}


	/*public FlatOwner getAllOwnerIds(FlatOwner fall) {
		// TODO Auto-generated method stub
		FlatOwner fo=fd.getAllOwnerIds(fall.getOwnerId());
		System.out.println("good");
		return fo;
		
		
	}*/


	public boolean isvalidateRent(int rentAmt) throws InvalidRentException{
		// TODO Auto-generated method stub
		String mob1=Long.toString(rentAmt);
		boolean res1=Pattern.matches("[1-9][0-9]{2}",mob1);
		if(res1==false)
			throw new InvalidRentException();
		return res1;
	}


	public boolean isvalidateDeposit(int depAmt) throws InvalidDepositException {
		// TODO Auto-generated method stub
		String mob12=Long.toString(depAmt);
		boolean res2=Pattern.matches("[1-9][0-9]{3}",mob12);
		if(res2==false)
			throw new InvalidDepositException();
		return res2;
	}


	public FlatOwner getAllOwnerIds(int ownerId) {
		// TODO Auto-generated method stub
		FlatOwner ff=fd.getAllOwnerIds(ownerId);
		
		return ff;
	}


	

}
