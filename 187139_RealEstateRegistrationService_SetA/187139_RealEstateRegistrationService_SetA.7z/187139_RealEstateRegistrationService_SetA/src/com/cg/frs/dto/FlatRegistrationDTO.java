package com.cg.frs.dto;

public class FlatRegistrationDTO {
	private int ownerId;
	private String ownerName;
	private String flatType;
	private int sqFt;
	private int rentAmt;
	private int depAmt;
	private long RegistrationId;
	public FlatRegistrationDTO(int ownerId, String ownerName, String flatType, int sqFt, int rentAmt, int depAmt,
			long registrationId) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.flatType = flatType;
		this.sqFt = sqFt;
		this.rentAmt = rentAmt;
		this.depAmt = depAmt;
		RegistrationId = registrationId;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getFlatType() {
		return flatType;
	}
	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}
	public int getSqFt() {
		return sqFt;
	}
	public void setSqFt(int sqFt) {
		this.sqFt = sqFt;
	}
	public int getRentAmt() {
		return rentAmt;
	}
	public void setRentAmt(int rentAmt) {
		this.rentAmt = rentAmt;
	}
	public int getDepAmt() {
		return depAmt;
	}
	public void setDepAmt(int depAmt) {
		this.depAmt = depAmt;
	}
	public long getRegistrationId() {
		return RegistrationId;
	}
	public void setRegistrationId(long registrationId) {
		RegistrationId = registrationId;
	}
	@Override
	public String toString() {
		return "FlatRegistrationDTO [ownerId=" + ownerId + ", ownerName=" + ownerName + ", flatType=" + flatType
				+ ", sqFt=" + sqFt + ", rentAmt=" + rentAmt + ", depAmt=" + depAmt + ", RegistrationId="
				+ RegistrationId + "]";
	}
	

}
