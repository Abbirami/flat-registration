package com.cg.frs.dto;

public class FlatOwner {
	private int ownerId;
	private String ownerName;
	private int mobile;
	public FlatOwner(int ownerId, String ownerName, int mobile) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.mobile = mobile;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "FlatOwner [ownerId=" + ownerId + ", ownerName=" + ownerName + ", mobile=" + mobile + "]";
	}
	
}